package com.pirate.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pirate.bean.Employee;
import com.pirate.util.DBUtil;

public class EmpDAO {
	public static int saveEmployee(Employee emp) {
		int status = 0;
		int id = 1;
		try {
			Connection conn = DBUtil.getConn();
			String getIdQuery = "SELECT max(id) FROM employee";
			String insertQuery = "INSERT INTO employee values(?,?,?,?)";
			PreparedStatement psId = conn.prepareStatement(getIdQuery);
			ResultSet rs = psId.executeQuery();
			while(rs.next()) {
				id = rs.getInt(1);
				id++;
			}
			PreparedStatement psInsert = conn.prepareStatement(insertQuery);
			psInsert.setInt(1, id);
			psInsert.setString(2, emp.getName());
			psInsert.setString(3, emp.getEmail());
			psInsert.setString(4, emp.getPswd());
			status = psInsert.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e);
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(e);
		}
		return status;
	}
	
	public static List<Employee> showAllEmp(){
		List<Employee> empList =  new ArrayList<>();
		try {
			Connection conn = DBUtil.getConn();
			String showQuery = "SELECT * FROM employee";
			PreparedStatement ps = conn.prepareStatement(showQuery);
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				Employee emp = new Employee();
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setEmail(rs.getString(3));
				emp.setPswd(rs.getString(4));
				empList.add(emp);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return empList;
	}
	
	public static int editUser(Employee emp) {
		int status = 0;
		try {
			Connection conn = DBUtil.getConn();
			String editQuery = "UPDATE employee set name = ?, email = ?, password = ? where id = ?";
			PreparedStatement ps = conn.prepareStatement(editQuery);
			ps.setString(1, emp.getName());
			ps.setString(2, emp.getEmail());
			ps.setString(3, emp.getPswd());
			ps.setInt(4, emp.getId());
			status = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return status;
	}

	public static Employee getEmpById(int id) {
		Employee emp = new Employee();
		try {
			Connection conn = DBUtil.getConn();
			String findQuery = "SELECT * FROM employee WHERE id = ?";
			PreparedStatement ps = conn.prepareStatement(findQuery);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				emp.setId(rs.getInt(1));
				emp.setName(rs.getString(2));
				emp.setEmail(rs.getString(3));
				emp.setPswd(rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return emp;
	}
	
	public static int deleteUser(int id) {
		int status = 0;
		try {
			Connection conn = DBUtil.getConn();
			String delQuery = "DELETE FROM employee where id = ?";
			PreparedStatement ps = conn.prepareStatement(delQuery);
			ps.setInt(1, id);
			status = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return status;
	}
}
