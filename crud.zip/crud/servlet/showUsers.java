package com.pirate.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pirate.bean.Employee;
import com.pirate.dao.EmpDAO;

@WebServlet("/showUsers")
public class showUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		request.getRequestDispatcher("WEB-INF/pages/showUser.jsp").forward(request, response);
/*		String spageId = request.getParameter("page");
		int pageId = Integer.parseInt(spageId);
		int total = 5;
		if (pageId == 1) {
			pageId = 1;
			total = 5;
		} else {
			pageId = pageId - 1;
			pageId = pageId * total + 1;
		}
		
		request.setAttribute("pageId", pageId);
		request.setAttribute("total", total);
		request.getRequestDispatcher("WEB-INF/pages/home.jsp").include(request, response);
		List<Employee> empList = EmpDAO.showAllEmp(pageId, total);
		out.print("<center><h1>Page No: "+spageId+"</h1>");  
		out.print("<br><table width='40%' style='text-align: center'>");
		out.print("<tr><th>Id</th><th>Name</th><th>Email</th><th>Edit</th><th>Delete</th></tr>");
		for (Employee emp : empList) {
			out.print("<tr><td>" + emp.getId() + "</td><td>" + emp.getName() + "</td><td>" + emp.getEmail()
					+ "</td><td><a href=editUser?id=" + emp.getId() + ">Edit</a></td><td><a href=deleteUser?id="
					+ emp.getId() + ">Delete</a></td></tr>");

		}
		out.print("</table><br>");
		for(int page=0;page<5;page++) {
			out.print("<a href=showUsers?page="+(page+1)+">"+(page+1)+" </a>");
		}
		out.print("</center>");*/
	}

}
