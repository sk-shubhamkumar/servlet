package com.pirate.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pirate.bean.Employee;
import com.pirate.dao.EmpDAO;

@WebServlet("/editUser")
public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
		Employee emp = EmpDAO.getEmpById(id);
		
		request.setAttribute("id", emp.getId());
		request.setAttribute("name", emp.getName());
		request.setAttribute("email", emp.getEmail());
		request.setAttribute("pswd", emp.getPswd());
		request.getRequestDispatcher("WEB-INF/pages/updateUser.jsp").forward(request, response);
	}

}
