package com.pir4t3.login;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 
		
		String uname = request.getParameter("uname");
		String pswd = request.getParameter("pswd");
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		if(uname.equals("admin") && pswd.equals("root")) {
			String name = "Shubham";
			request.setAttribute("myname", name);
			RequestDispatcher rd = request.getRequestDispatcher("Hello.jsp");
			rd.forward(request, response);
	        Cookie ck=new Cookie("cname",uname);  
	        response.addCookie(ck);  
	        System.out.println(ck);
		}
		else {
			out.print("<center>login failed</center>");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
	}

}
